import express from 'express';
import { studentRouter } from './student/studentRouter.js';
import { adminRouter } from './admin/adminRouter.js';
import { trainerRouter } from './trainer/trainerRouter.js';
export const mainRouter = express.Router();
import { AuthMiddleware } from '../middleware/authMiddleware.js';
import jwt from 'jsonwebtoken'
import {generateToken} from '../libs/libs.js'


mainRouter.use("/student", studentRouter)
mainRouter.use("/trainer", trainerRouter)
mainRouter.use("/admin", adminRouter)
mainRouter.post("/refresh-token", (req, res) => {
    console.log(req.body)

    let { userId } = jwt.verify(req.body.refreshtoken, process.env.JWT_SECRET)
    if (!userId) {
        return res.json({
            message: "token or id not found!"
        })
       
    }
        console.log(userId)

     let accesstoken = generateToken('1m', userId)
        return res.json({
            message: "refresh token",
            token: accesstoken

        })
})