import express from 'express'
import http from 'http'
import cors from 'cors'
import 'dotenv/config'
import { connectMongo } from './config/mongo-config.js'
import { mainRouter } from './routers/mainRouter.js'
import { Server } from 'socket.io';
import { mongoose } from 'mongoose'
import { messageSchemaModel } from './models/message.js'

const app = express()
const server = http.createServer(app)  //API

// socket : express 

const io = new Server(server)

let port = process.env.PORT || 5000 // Fixed typo: process.env.PORT (capital letters)


io.on("connection", (socket) => {

    console.log("✅ User connected:", socket.id);


    // JOIN ROOM
    socket.on("join_room", (roomid) => {

        socket.join(roomid);

        console.log(`✅ User ${socket.id} joined room: ${roomid}`);

    });


    // SEND MESSAGE
    socket.on("send_message", async ({
        roomid,
        senderId,
        reciverId,
        message
    }) => {

        try {

            console.log("📩 Message received from client");

            console.log({
                roomid,
                senderId,
                reciverId,
                message
            });


            // STORE IN MONGODB
            const newMessage = await messageSchemaModel.create({
                roomid,
                senderId,
                reciverId,
                message
            });


            console.log("✅ Message stored in MongoDB");
            console.log(newMessage);


            // SEND TO ROOM
            io.to(roomid).emit("recieve_message", {
                newMessage
            });


            console.log("✅ Message emitted to room:", roomid);


        } catch (error) {

            console.log("❌ Message error:", error);

        }

    });


    // DISCONNECT
    socket.on("disconnect", () => {

        console.log(
            `❌ User disconnected. Socket ID: ${socket.id}`
        );

    });

});
connectMongo()

app.use(cors());
app.use(express.json());


app.use("/api", mainRouter);


app.use('/images', express.static('uploads/images'));

app.get("/", (req, res) => {
    res.json({ message: "ok" })
})

// Use server.listen instead of app.listen to support both Express and Socket.io
server.listen(port, () => {
    console.log('Backend is running on port ' + port)
})
