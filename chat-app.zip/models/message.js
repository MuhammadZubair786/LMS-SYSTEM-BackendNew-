import mongoose from "mongoose";


const messageSchema = new mongoose.Schema({
    roomid: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "chat_Rooms"
    },
    senderId: {
        type: String,
        ref: "User",
    },
    reciverId: {
        type: String,
        ref: "User",
    },
    message :{
        type:String,
        required:true
    }
})

export const messageSchemaModel = mongoose.model('messages', messageSchema)