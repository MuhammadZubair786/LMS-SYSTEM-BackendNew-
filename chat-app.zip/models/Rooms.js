import mongoose from "mongoose";


const roomSchema = new mongoose.Schema({
    roomid: {
        type: String,
        required: true,
        unique: true
    },
    senderId: {
        type:mongoose.Schema.Types.ObjectId,
        ref: "User",
    },
    reciverId: {
        type:mongoose.Schema.Types.ObjectId,
        ref: "User",
    },
})

export const roomSchemaModel = mongoose.model('chat_Rooms', roomSchema)