import express from "express"
const router = express()

router.post("/signup",(req,res)=>{
    return res.json({message :"ok"})
})



export default router