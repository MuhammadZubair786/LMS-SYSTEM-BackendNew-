import { signupValidator } from "../../validator/signupValidator.js"
import { userModel } from "../../models/user.js";
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { sendOtpEmail, generateOtp, generateToken, sendResetPasswordEmail } from '../../libs/libs.js'
import { roomSchemaModel } from "../../models/Rooms.js";

import crypto from "crypto"

export const Signup = async (req, res) => {
    try {
        console.log("test")
        req.body.role = 'student';
        console.log(req.file)
        req.body.image = req.file.filename;
        await signupValidator.validate(req.body)//sends to catch if error found
        let otp = generateOtp()
        let hashedPassword = await bcrypt.hash(req.body.password, 12);
        req.body.password = hashedPassword
        req.body.otp = otp;
        let user = userModel(req.body)
        await user.save();
        let token = generateToken('2h', user._id)
        await sendOtpEmail('samishaikh12313@gmail.com', req.body.email, otp)
        return res.status(201).json({
            message: "user created successfully",
            token
        })
    } catch (err) {
        console.log(err)
        return res.status(500).json({
            message: "internal server error"
        })
    }
}

export const VerifyOtp = async (req, res) => {
    try {
        let token = req.headers.authorization?.split(" ")[1];
        if (!token) {
            return res.status(400).json({
                message: "token not found"
            })
        }
        let { otp } = req.body
        if (!otp) {
            return res.status(400).json({
                message: "otp not found!"
            })
        }
        let { userId } = jwt.verify(token, process.env.JWT_SECRET)
        let user = await userModel.findOne({ _id: userId });
        let { otp: savedOtp } = user
        if (otp != savedOtp) {
            return res.status(400).json({
                message: "otp not matched, invalid otp"
            })
        }
        console.log(otp, savedOtp)
        user.verified = true;
        user.save();

        return res.status(200).json({
            message: "success! user verified!"
        })
    } catch (err) {
        console.log(err)
    }
}

export const Login = async (req, res) => {
    try {
        let { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({
                message: "bad request"
            })
        }
        let user = await userModel.findOne({ email })
        if (!user) {
            return res.status(400).json({
                message: "invalid credentials, user not found"
            })
        }

        if (!user.verified) {
            let otp = generateOtp()
            user.otp = otp;
            await user.save();
            await sendOtpEmail('samishaikh12313@gmail.com', email, otp);
            let token = generateToken('2h', user._id)
            return res.status(200).json({
                message: "email sent to user email to verify account!"
            })
        }

        let compare = await bcrypt.compare(password, user.password)
        if (!compare) {
            return res.status(400).json({
                message: "invalid credentials!"
            })
        }
        let accesstoken = generateToken('1m', user._id)
        let Refreshtoken = generateToken('1h', user._id)

        return res.status(200).json({
            message: "login success!",
            data: { ...user._doc, accesstoken, Refreshtoken }
        })

    }
    catch (err) {
        console.log(err)
        return res.status(500).json({
            message: "internal server error"
        })
    }

}

export const forgotPassword = async (req, res) => {
    try {
        let { email } = req.body;
        if (!email) {
            return res.status(400).json({
                message: "bad request, email not found"
            })
        }
        let user = await userModel.findOne({ email })
        if (!user) {
            return res.status(404).json({
                message: "user not found"
            })
        }
        let token = generateToken('1h', user._id)
        await sendResetPasswordEmail('samishaikh12313@gmail.com', email, token);
        return res.status(200).json({
            message: "reset password email has been sent!"
        })
    } catch (err) {
        console.log(err)
        return res.status(500).json({
            message: "internal server error!"
        })
    }
}

export const resetPassword = async (req, res) => {
    try {
        let token = req.headers.authorization?.split(" ")[1];
        if (!token) {
            return res.status(400).json({
                message: "token not found"
            })
        }
        let { password } = req.body
        if (!password) {
            return res.status(400).json({
                message: "new password not found!"
            })
        }
        let { userId } = jwt.verify(token, process.env.JWT_SECRET)
        let user = await userModel.findOne({ _id: userId });
        if (!user) {
            return res.status(404).json({
                message: "user not found"
            })
        }
        let hashPassword = await bcrypt.hash(password, 12)
        user.password = hashPassword;
        await user.save()
        return res.status(200).json({
            message: "password reset success!"
        })
    } catch (err) {
        console.log(err)
        return res.status(500).json({
            message: "internal server error!"
        })
    }
}


export const roomCreate = async (req, res) => {
    const checkRoom = await roomSchemaModel.findOne({
        $or: [
            { senderId: req.body.senderId, reciverId: req.body.reciverId },
            { senderId: req.body.reciverId, reciverId: req.body.senderId }
        ]
    });
    if (checkRoom) {
        return res.json({
            message: "Room get",
            data: checkRoom
        })

    }
    else {
        const roomId = crypto.randomBytes(4).toString("hex")
        const room = await roomSchemaModel.create({
            roomid:roomId,
            senderId: req.body.senderId,
            reciverId: req.body.reciverId
        })

        res.json({
            message: "room create",
            data: room
        })
    }
}

